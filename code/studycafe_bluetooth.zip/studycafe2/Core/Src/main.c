/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define min(a,b) (((a) < (b)) ? (a) : (b))
#define max(a,b) (((a) > (b)) ? (a) : (b))

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

#define ARR_CNT   8     // 토큰 최대 개수
#define CMD_SIZE  64    // 한 줄 최대 길이
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* ---- BT 수신 ---- */
static volatile uint8_t  bt_rx = 0;
static volatile uint16_t bt_len = 0;
static char              bt_line[CMD_SIZE];
static volatile uint8_t  btFlag = 0;

/* ---- 디버그(선택) ---- */
static volatile uint8_t  dbg_rx = 0;
static volatile uint16_t dbg_len = 0;
static char              dbg_line[64];
static volatile uint8_t  rx2Flag = 0;

/* ---- LCD(PCF8574) ---- */
static uint8_t lcd_addr = (0x27 << 1); // 0x27 또는 0x3F

/* 현재 상태 캐시 */
//static int    seat_free  = -1;
//static int    seat_total = -1;
static int    seat_free  = 0;
static int    seat_total = 20;
static char   seat_status[8] = "OPEN";
static float  env_temp = NAN;
static float  env_hum  = NAN;
static int    env_noise = -1;

/* 타임아웃 표시용 */
static uint32_t last_msg_tick = 0;

volatile int pin_flag = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
static void start_bt_rx_it(void);
static void start_dbg_rx_it(void);

static void I2C_ScanBus_SetLCDAddress(void);
static void LCD_Init(void);
static void LCD_Clear(void);
static void LCD_SetCursor(uint8_t col,uint8_t row);
static void LCD_Data(uint8_t d);
static void LCD_PrintPadded16(const char* s);

static void render_view(void);
static void bluetooth_Event(const char* btData);
static void BT_Send(const char* s);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
PUTCHAR_PROTOTYPE { HAL_UART_Transmit(&huart2,(uint8_t*)&ch,1,0xFFFF); return ch; }

/* ---- LCD 드라이버 ---- */
#define LCD_BACKLIGHT 0x08
#define LCD_ENABLE    0x04
#define LCD_RW        0x02
#define LCD_RS        0x01

static void I2C_Delay(void){ for(volatile int i=0;i<200;i++); }
static void I2C_LCD_Write(uint8_t d){ HAL_I2C_Master_Transmit(&hi2c1, lcd_addr, &d, 1, 10); }
static void I2C_LCD_PulseEnable(uint8_t d){ I2C_LCD_Write(d|LCD_ENABLE); I2C_Delay(); I2C_LCD_Write(d & (uint8_t)~LCD_ENABLE); I2C_Delay(); }
static void I2C_LCD_SendNibble(uint8_t d, uint8_t rs){ uint8_t o=(d&0xF0)|LCD_BACKLIGHT|(rs?LCD_RS:0); I2C_LCD_Write(o); I2C_LCD_PulseEnable(o); }
static void I2C_LCD_SendByte(uint8_t d, uint8_t rs){ I2C_LCD_SendNibble(d,rs); I2C_LCD_SendNibble((uint8_t)(d<<4),rs); }
static void LCD_Command(uint8_t c){ I2C_LCD_SendByte(c,0); HAL_Delay(2); }
static void LCD_Data(uint8_t d){ I2C_LCD_SendByte(d,1); }
static void LCD_Clear(void){ LCD_Command(0x01); HAL_Delay(2); }
static void LCD_SetCursor(uint8_t col,uint8_t row){ static const uint8_t off[]={0x00,0x40,0x14,0x54}; LCD_Command(0x80|(col+off[row])); }
static void LCD_PrintPadded16(const char* s){ char buf[17]; memset(buf,' ',16); buf[16]=0; if(s) strncpy(buf,s,16); for(int i=0;i<16;i++) LCD_Data((uint8_t)buf[i]); }
static void LCD_Init(void){ HAL_Delay(50); I2C_LCD_SendNibble(0x30,0); HAL_Delay(5); I2C_LCD_SendNibble(0x30,0); HAL_Delay(5); I2C_LCD_SendNibble(0x20,0); HAL_Delay(5); LCD_Command(0x28); LCD_Command(0x08); LCD_Command(0x01); HAL_Delay(2); LCD_Command(0x06); LCD_Command(0x0C); }

static void I2C_ScanBus_SetLCDAddress(void){
  for(uint8_t a7=0x20;a7<=0x3F;++a7){ uint16_t a8=(uint16_t)(a7<<1);
    if(HAL_I2C_IsDeviceReady(&hi2c1,a8,1,50)==HAL_OK){ lcd_addr=a8; return; } }
}

/* 현재 상태 렌더링 */
static void render_view(void){
  char l1[17]={0}, l2[17]={0};

  if(seat_free>=0 && seat_total>0) snprintf(l1,sizeof(l1),"SEAT %2d/%2d", seat_free, seat_total);
  else strncpy(l1,"STM READY",sizeof(l1)-1);

  if(strcmp(seat_status,"FULL")==0 || (seat_total>0 && seat_free==0)){
    strncpy(l2,"FULL",sizeof(l2)-1);
  } else {
    char t[8]="", h[8]="", n[8]="";
    if(!isnan(env_temp)) snprintf(t,sizeof(t),"%0.1fC",env_temp);
    if(!isnan(env_hum))  snprintf(h,sizeof(h), "%0.0f%%",env_hum);

    bool first=true;
    if(t[0]){ strncat(l2,t,sizeof(l2)-1); first=false; }
    if(h[0]){ if(!first) strncat(l2," ",sizeof(l2)-1); strncat(l2,h,sizeof(l2)-1); first=false; }
    if(n[0]){ if(!first) strncat(l2," ",sizeof(l2)-1); strncat(l2,n,sizeof(l2)-1); }
    if(l2[0]==0) strncpy(l2,"WAITING BT...",sizeof(l2)-1);
  }

  LCD_SetCursor(0,0); LCD_PrintPadded16(l1);
  LCD_SetCursor(0,1); LCD_PrintPadded16(l2);
}

/* BT 송신 */
static void BT_Send(const char* s){ HAL_UART_Transmit(&huart1,(uint8_t*)s,(uint16_t)strlen(s),0xFFFF); }

/* 교수님 포맷 파서 + 동작 */
static void bluetooth_Event(const char* btData)
{
  // btData 예: "[STM_LCD]SEAT@3@20"
  char recvBuf[CMD_SIZE]; strncpy(recvBuf, btData, sizeof(recvBuf)-1); recvBuf[sizeof(recvBuf)-1]=0;

  // 토큰 구분자는 "[@]" → [, @, ] 셋 모두 구분자로 취급 (교수님 코드 방식)
  char *pArray[ARR_CNT]={0};
  int i=0;
  char *tok = strtok(recvBuf, "[@]");
  while(tok && i<ARR_CNT){ pArray[i++]=tok; tok=strtok(NULL,"[@]"); }

  // 인덱스 의미(관례): pArray[0]=보낸ID, pArray[1]=CMD, pArray[2..]=인자
  if(i<2 || !pArray[1]) return;

  // 연결 알림 무시(교수님 코드 호환)
  if(strncmp(pArray[1]," New conn", sizeof(" New conn")-1)==0) return;
  if(strncmp(pArray[1]," Already log", sizeof(" Already log")-1)==0) return;

  // LED 제어(원본 호환)
  if(strcmp(pArray[1],"LED")==0 && pArray[2]){
    if(strcmp(pArray[2],"ON")==0)  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
    if(strcmp(pArray[2],"OFF")==0) HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
    return;
  }

  // 좌석
  if(strcmp(pArray[1],"SEAT")==0 && pArray[2] && pArray[3]){
    seat_free  = atoi(pArray[2]);
    seat_total = atoi(pArray[3]);
    strcpy(seat_status, (seat_total>0 && seat_free==0) ? "FULL" : "OPEN");
    last_msg_tick = HAL_GetTick();
    render_view();
    return;
  }

  // DESK@<ON/OFF>
  if (strcmp(pArray[1], "DESK") == 0 && pArray[2])
  {
		if (strcmp(pArray[2], "ON") == 0)
			seat_free++;
		if (strcmp(pArray[2], "OFF") == 0)
			seat_free--;

		seat_free = max(0 , min(seat_free, seat_total));

		strcpy(seat_status, (seat_total > 0 && seat_free == 0) ? "FULL" : "OPEN");
		last_msg_tick = HAL_GetTick();
		render_view();
		return;
  }

  // 상태
  if(strcmp(pArray[1],"STATUS")==0 && pArray[2]){
    if(strncmp(pArray[2],"FULL",4)==0) strcpy(seat_status,"FULL");
    else strcpy(seat_status,"OPEN");
    last_msg_tick = HAL_GetTick();
    render_view();
    return;
  }

  // 환경 (ENV@T@H@N 대신, 요구대로 ENV@<temp>@<humi>@<noise>)
  if(strcmp(pArray[1],"ENV")==0 && pArray[2] && pArray[3] && pArray[4]){
    env_temp  = strtof(pArray[2],NULL);
    env_hum   = strtof(pArray[3],NULL);
    env_noise = atoi(pArray[4]);
    last_msg_tick = HAL_GetTick();
    render_view();
    return;
  }

  // 메시지
  if(strcmp(pArray[1],"MSG")==0 && pArray[2]){
    const char* line = pArray[2];          // L1 / L2
    const char* text = (i>=4 && pArray[3]) ? pArray[3] : ""; // 공백 포함 가능
    if(strcmp(line,"L2")==0){ LCD_SetCursor(0,1); LCD_PrintPadded16(text); }
    else                    { LCD_SetCursor(0,0); LCD_PrintPadded16(text); }
    last_msg_tick = HAL_GetTick();
    return;
  }

  // 그 외는 무시
}

/* 수신 인터럽트 시작 */
static void start_bt_rx_it(void){ HAL_UART_Receive_IT(&huart1,(uint8_t*)&bt_rx,1); }
static void start_dbg_rx_it(void){ HAL_UART_Receive_IT(&huart2,(uint8_t*)&dbg_rx,1); }
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  I2C_ScanBus_SetLCDAddress();
  LCD_Init();
  LCD_Clear();
  LCD_SetCursor(0,0); LCD_PrintPadded16("LCD SELF-TEST");
  LCD_SetCursor(0,1); LCD_PrintPadded16("LCD READY");
  HAL_Delay(600);
  LCD_Clear();
  LCD_SetCursor(0,0); LCD_PrintPadded16("STM READY");
  LCD_SetCursor(0,1); LCD_PrintPadded16("WAITING BT...");

  start_bt_rx_it();
  start_dbg_rx_it();

  last_msg_tick = HAL_GetTick();

  BT_Send("[STM_LCD:PASSWD]\n");
  printf("start main() / BT login sent\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	    if(btFlag){ btFlag=0; bluetooth_Event(bt_line); }

	    if (pin_flag)
	    {
	    	pin_flag = 0;
	    	BT_Send("[17]DESK@ON\n");
	    }

	    // 10초 무데이터면 안내
	    uint32_t now = HAL_GetTick();
	    if(now - last_msg_tick > 10000U){
	      LCD_Clear();
	      LCD_SetCursor(0,0); LCD_PrintPadded16("NO DATA");
	      LCD_SetCursor(0,1); LCD_PrintPadded16("CHECK LINK/DB");
	      last_msg_tick = now;
	    }

	    HAL_Delay(5);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
 }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == B1_Pin)
	{
		printf("pin callback\r\n");
		static uint32_t last_tick = 0;
		uint32_t now = HAL_GetTick();
		if((now - last_tick) < 200){
		return;
		}
		last_tick = now;
		pin_flag = 1;

		//		BT_Send("[17]DESK@ON\n");
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if(huart->Instance == USART1){
    char c=(char)bt_rx;
    if(c=='\n' || c=='\r'){
      if(bt_len>0){ bt_line[bt_len]=0; bt_len=0; btFlag=1; }
    }else{
      if(bt_len < (sizeof(bt_line)-1)) bt_line[bt_len++]=c; else bt_len=0;
    }
    HAL_UART_Receive_IT(&huart1,(uint8_t*)&bt_rx,1);
  }
  else if(huart->Instance == USART2){
    char c=(char)dbg_rx;
    if(c=='\n' || c=='\r'){
      if(dbg_len>0){ dbg_line[dbg_len]=0; dbg_len=0; rx2Flag=1; printf("DBG>%s\r\n", dbg_line); }
    }else{
      if(dbg_len < (sizeof(dbg_line)-1)) dbg_line[dbg_len++]=c; else dbg_len=0;
    }
    HAL_UART_Receive_IT(&huart2,(uint8_t*)&dbg_rx,1);
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
